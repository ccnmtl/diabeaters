from models import Section, Hierarchy, SectionChildren, PageBlock

from django.contrib import admin

admin.site.register(Hierarchy)
admin.site.register(Section)
admin.site.register(SectionChildren)
admin.site.register(PageBlock)
